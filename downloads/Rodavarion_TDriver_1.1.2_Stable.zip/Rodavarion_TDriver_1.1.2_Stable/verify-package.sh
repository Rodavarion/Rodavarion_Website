#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"
VERSION="$(tr -d '[:space:]' < VERSION)"
[[ "$VERSION" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]]
sha256sum -c manifest.sha256
bash -n install.sh release.sh publish-and-install.sh tools/*.sh
./tools/release_manager.sh check >/dev/null
grep -q 'PrepareForSleep' src/daemon/main.cpp
grep -q 'rodavarion/core/Logger.hpp' src/gui/MainWindow.cpp
grep -q 'recoverAfterResume' src/gui/MainWindow.cpp
grep -q 'startHealthMonitor' src/gui/MainWindow.cpp
grep -q 'qt6_wrap_cpp(RODAVARION_GUI_MOC_SOURCES' CMakeLists.txt
grep -q 'gh release create' release.sh
grep -q 'git tag -a' release.sh
grep -q 'release_manager.sh check' release.sh
grep -q 'clean_release_tree.sh.*--staging' release.sh
grep -q 'release_items=(' release.sh
grep -q 'sudo pacman -S --needed --noconfirm' release.sh
grep -q 'QApplication::setApplicationVersion' src/app/main.cpp
grep -q 'QCoreApplication::setApplicationVersion' src/cli/main.cpp
grep -q 'applicationVersion()' src/gui/MainWindow.cpp
test -f "RELEASE_NOTES_${VERSION}.md"
test -x tools/audit_github_repository.sh
test -x tools/release_manager.sh
test -x tools/clean_release_tree.sh
test -x release.sh
! find . -maxdepth 2 -type f \( -name 'CHANGELOG_RC*.md' -o -name 'CHANGELOG_BETA*.md' -o -name 'RELEASE_NOTES_1.0.0.md' \) | grep -q .
echo "PASS: TDriver ${VERSION} Stable package verified"
