#!/usr/bin/env bash
set -Eeuo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "publish-and-install.sh is kept for compatibility; starting release.sh"
exec "$ROOT_DIR/release.sh" "$@"
