# Rodavarion TDriver 1.1.2 Stable

## Release workflow and package hygiene

- Added one-command `release.sh` workflow.
- Missing Arch Linux release tools are installed before release identity checks.
- `VERSION` remains the single source of truth for application, archive and Git tag versions.
- Release archives are built from an explicit allowlist instead of copying the working tree.
- Build directories, caches, editor files, logs, temporary files and historical prerelease documents are excluded.
- Package verification checks that obsolete RC/Beta files cannot return to Stable archives.
- Existing user profiles, settings and logs are preserved during upgrades.
