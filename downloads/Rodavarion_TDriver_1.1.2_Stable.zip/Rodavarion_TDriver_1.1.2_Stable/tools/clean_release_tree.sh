#!/usr/bin/env bash
set -Eeuo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
MODE="${1:---working-tree}"

clean_generated_tree() {
  local target="$1"
  find "$target" -depth \
    \( -type d \( -name build -o -name 'build-*' -o -name CMakeFiles -o -name .cache -o -name __pycache__ -o -name .pytest_cache -o -name .mypy_cache -o -name .idea -o -name .vscode \) \
       -o -type f \( -name '*.o' -o -name '*.obj' -o -name '*.a' -o -name '*.so' -o -name '*.log' -o -name '*.tmp' -o -name '*.swp' -o -name '*~' -o -name '.DS_Store' -o -name 'CMakeCache.txt' -o -name 'compile_commands.json' \) \) \
    -print -exec rm -rf -- {} + 2>/dev/null || true
}

case "$MODE" in
  --working-tree)
    echo "=== CLEAN GENERATED WORKING-TREE FILES ==="
    clean_generated_tree "$ROOT_DIR"
    echo "PASS: generated files removed; source, profiles and user data were not touched"
    ;;
  --staging)
    target="${2:?Usage: $0 --staging DIRECTORY}"
    [ -d "$target" ] || { echo "ПОМИЛКА: staging directory not found: $target" >&2; exit 2; }
    clean_generated_tree "$target"
    rm -rf "$target/.git" "$target/.github"
    rm -f "$target"/CHANGELOG_RC*.md "$target"/CHANGELOG_BETA*.md
    rm -f "$target"/docs/ARCHITECTURE_1_0_ALPHA.md "$target"/docs/RELEASE_CHECKS_BETA*.md
    find "$target" -type f \( -name '*.bundle' -o -name '*.zip' -o -name '*.tar' -o -name '*.tar.gz' \) -delete
    echo "PASS: staging tree sanitized"
    ;;
  *)
    echo "Usage: $0 [--working-tree | --staging DIRECTORY]" >&2
    exit 2
    ;;
esac
