#!/usr/bin/env bash
set -Eeuo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
VERSION_FILE="$ROOT_DIR/VERSION"
command_name="${1:-status}"

read_version() {
    tr -d '[:space:]' < "$VERSION_FILE"
}

validate_version() {
    local version="$1"
    [[ "$version" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]] || {
        echo "ПОМИЛКА: некоректна версія '$version'. Очікується MAJOR.MINOR.PATCH." >&2
        exit 2
    }
}

case "$command_name" in
    status|check)
        version="$(read_version)"
        validate_version "$version"
        archive="Rodavarion_TDriver_${version}_Stable.zip"
        grep -q "RODAVARION_VERSION_STRING" "$ROOT_DIR/CMakeLists.txt"
        grep -q 'QApplication::setApplicationVersion' "$ROOT_DIR/src/app/main.cpp"
        grep -q 'applicationVersion()' "$ROOT_DIR/src/gui/MainWindow.cpp"
        echo "Version source: VERSION = $version"
        echo "Window title: Rodavarion TDriver — v$version"
        echo "Archive: $archive"
        echo "Git tag: v$version"
        ;;
    next-patch)
        current="$(read_version)"
        validate_version "$current"
        IFS=. read -r major minor patch <<<"$current"
        next="$major.$minor.$((patch + 1))"
        printf '%s\n' "$next" > "$VERSION_FILE"
        echo "Version advanced: $current -> $next"
        echo "Now regenerate manifest.sha256 before packaging."
        ;;
    set)
        next="${2:-}"
        validate_version "$next"
        printf '%s\n' "$next" > "$VERSION_FILE"
        echo "Version set to $next"
        ;;
    *)
        echo "Usage: $0 {status|check|next-patch|set X.Y.Z}" >&2
        exit 2
        ;;
esac
