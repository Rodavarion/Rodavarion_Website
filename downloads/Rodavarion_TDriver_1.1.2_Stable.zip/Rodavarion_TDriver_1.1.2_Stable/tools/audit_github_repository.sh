#!/usr/bin/env bash
set -Eeuo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
REPO="${RODAVARION_TDRIVER_REPO:-$HOME/Документи/RodavarionTechnologies/TDriver}"
REPORT_DIR="${RODAVARION_AUDIT_REPORT_DIR:-$HOME/Завантажене/TDriver_GitHub_Audit}"
mkdir -p "$REPORT_DIR"
STAMP="$(date +%Y%m%d-%H%M%S)"
REPORT="$REPORT_DIR/audit-$STAMP.txt"
BUNDLE="$REPORT_DIR/TDriver-before-$STAMP.bundle"
exec > >(tee "$REPORT") 2>&1

echo "=== TDriver GitHub safety audit ==="
test -d "$REPO/.git" || { echo "ПОМИЛКА: Git repository not found: $REPO" >&2; exit 30; }
cd "$REPO"

echo "Repository: $REPO"
echo "Branch: $(git branch --show-current)"
echo "Remote: $(git remote get-url origin 2>/dev/null || echo none)"

if [ -n "$(git status --porcelain)" ]; then
  echo "ПОМИЛКА: repository has uncommitted changes; nothing was modified." >&2
  git status --short >&2
  exit 31
fi

git fetch --all --prune
git bundle create "$BUNDLE" --all
echo "Backup bundle: $BUNDLE"

# Only ignored files are eligible for automatic cleanup. Tracked and untracked
# source files are never deleted by this script.
echo "--- Ignored build/cache files eligible for cleanup ---"
git clean -ndX

echo "--- Suspicious tracked paths ---"
git ls-files | grep -Ei '(^|/)(build|dist|out|cmake-build[^/]*)/|\.(zip|tar|gz|7z|o|a|so|dll|exe|AppImage)$|(^|/)\.env($|\.)|id_(rsa|ed25519)$' || true

echo "--- Possible secrets (names only, no secret values printed) ---"
git grep -IlE '(BEGIN (RSA|OPENSSH|EC) PRIVATE KEY|api[_-]?key|access[_-]?token|client[_-]?secret|password[[:space:]]*=)' -- . ':!*.md' ':!LICENSE' || true

echo "--- Duplicate release/history documents retained for review ---"
find . -maxdepth 2 -type f \( -iname '*RC*' -o -iname '*BETA*' -o -iname '*ALPHA*' \) -print | sort

echo "--- Repository integrity ---"
git fsck --full

echo "--- Source tree comparison against release package ---"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
rsync -a --delete --exclude='.git/' --exclude='build/' "$ROOT_DIR/" "$TMP/release/"
# Report tracked files missing from release, but never delete them.
while IFS= read -r file; do
  [ -e "$ROOT_DIR/$file" ] || echo "TRACKED_ONLY_IN_GITHUB: $file"
done < <(git ls-files)

echo "PASS: audit completed without deleting any tracked or untracked source file"
echo "Report: $REPORT"
