#!/usr/bin/env bash
(
set -Eeuo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WEBSITE_ROOT="${RODAVARION_WEBSITE_ROOT:-$HOME/Документи/RodavarionTechnologies/Website}"
PROJECT_NAME="${RODAVARION_PAGES_PROJECT:-rodavarion}"
TDRIVER_REPO="${RODAVARION_TDRIVER_REPO:-$HOME/Документи/RodavarionTechnologies/TDriver}"
VERSION="$(tr -d '[:space:]' < "$ROOT_DIR/VERSION")"
[[ "$VERSION" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]] || { echo "ПОМИЛКА: VERSION має бути X.Y.Z" >&2; exit 10; }
TAG="v${VERSION}"
ARCHIVE_NAME="Rodavarion_TDriver_${VERSION}_Stable.zip"
ARCHIVE_PATH="$HOME/Завантажене/$ARCHIVE_NAME"

ensure_arch_tools() {
  local missing=() cmd pkg
  for pair in "zip:zip" "unzip:unzip" "gh:github-cli" "curl:curl" "git:git" "cmake:cmake" "ninja:ninja"; do
    cmd="${pair%%:*}"; pkg="${pair##*:}"
    command -v "$cmd" >/dev/null 2>&1 || missing+=("$pkg")
  done
  if ((${#missing[@]})); then
    command -v pacman >/dev/null 2>&1 || { echo "ПОМИЛКА: відсутні ${missing[*]}, а pacman не знайдено" >&2; exit 11; }
    echo "Встановлення відсутніх інструментів: ${missing[*]}"
    sudo pacman -S --needed --noconfirm "${missing[@]}"
  fi
  for cmd in zip unzip gh curl git cmake ninja; do
    command -v "$cmd" >/dev/null 2>&1 || { echo "ПОМИЛКА: після встановлення не знайдено $cmd" >&2; exit 12; }
  done
}

create_clean_archive() {
  local tmp export item
  tmp="$(mktemp -d)"
  trap 'rm -rf "$tmp"' RETURN
  export="$tmp/Rodavarion_TDriver_${VERSION}_Stable"
  mkdir -p "$export"

  # Explicit release allowlist: adding a new top-level component requires a conscious edit here.
  local release_items=(
    VERSION CMakeLists.txt README.md CHANGELOG.md RELEASE_NOTES_${VERSION}.md
    LICENSE ACKNOWLEDGEMENTS.md CODE_OF_CONDUCT.md CONTRIBUTING.md ROADMAP.md SUPPORT.md
    .gitignore .gitattributes
    config include src tests docs packaging tools
    install.sh release.sh publish-and-install.sh verify-package.sh
  )
  for item in "${release_items[@]}"; do
    [ -e "$ROOT_DIR/$item" ] || { echo "ПОМИЛКА: release allowlist item missing: $item" >&2; exit 30; }
    cp -a "$ROOT_DIR/$item" "$export/"
  done

  "$ROOT_DIR/tools/clean_release_tree.sh" --staging "$export"
  (
    cd "$export"
    find . -type f ! -name manifest.sha256 -print0 | sort -z | xargs -0 sha256sum > manifest.sha256
  )
  rm -f "$ARCHIVE_PATH"
  (cd "$tmp" && zip -qr "$ARCHIVE_PATH" "$(basename "$export")")
  unzip -t "$ARCHIVE_PATH" >/dev/null
  echo "$(sha256sum "$ARCHIVE_PATH" | awk '{print $1}')  $ARCHIVE_PATH"
  rm -rf "$tmp"
  trap - RETURN
}

ensure_arch_tools
cd "$ROOT_DIR"
chmod +x install.sh release.sh publish-and-install.sh verify-package.sh tools/*.sh

# Clean generated project artifacts only. Never remove source or user configuration.
./tools/clean_release_tree.sh --working-tree

echo "=== RELEASE IDENTITY CHECK ==="
./tools/release_manager.sh check
./verify-package.sh

echo "=== 1/6 VERIFY / INSTALL ON THIS LAPTOP ==="
./install.sh --edition full --yes

echo "=== VERIFY LOCAL INSTALLATION ==="
test -x "$HOME/.local/bin/rodavarion-tdriver"
test -x "$HOME/.local/bin/rodavarion-tdriverd"
systemctl --user is-enabled --quiet rodavarion-tdriverd.service
systemctl --user restart rodavarion-tdriverd.service
systemctl --user is-active --quiet rodavarion-tdriverd.service
pkill -u "$UID" -f '^.*/rodavarion-tdriver( --tray)?$' >/dev/null 2>&1 || true
for _ in {1..30}; do pgrep -u "$UID" -f '^.*/rodavarion-tdriver( --tray)?$' >/dev/null || break; sleep 0.1; done
nohup "$HOME/.local/bin/rodavarion-tdriver" --tray >"$HOME/.local/share/rodavarion-tdriver/gui-start.log" 2>&1 &
sleep 2
pgrep -u "$UID" -f "$HOME/.local/bin/rodavarion-tdriver" >/dev/null
echo "PASS: TDriver $VERSION installed and running on this laptop"

echo "=== 2/6 AUDIT / SYNC GITHUB TREE ==="
./tools/audit_github_repository.sh
cd "$TDRIVER_REPO"
git fetch --all --prune
if git rev-parse "$TAG" >/dev/null 2>&1 || git ls-remote --exit-code --tags origin "refs/tags/$TAG" >/dev/null 2>&1; then
  echo "ПОМИЛКА: реліз $TAG вже існує. Збільш PATCH-версію." >&2; exit 14
fi
git add -A
git diff --cached --check
if ! git diff --cached --quiet; then git commit -m "Release TDriver ${VERSION} Stable"; git push origin main; fi

echo "=== 3/6 CREATE CLEAN RELEASE ARCHIVE ==="
create_clean_archive

echo "=== CREATE PROTECTED GIT TAG / GITHUB RELEASE ==="
cd "$TDRIVER_REPO"
git tag -a "$TAG" -m "Rodavarion TDriver ${VERSION} Stable"
git push origin "$TAG"
gh auth status >/dev/null
gh release create "$TAG" "$ARCHIVE_PATH" --repo Rodavarion/Rodavarion_TDriver --title "Rodavarion TDriver ${VERSION} Stable" --notes-file "$ROOT_DIR/RELEASE_NOTES_${VERSION}.md" --verify-tag

echo "=== 4/6 UPDATE WEBSITE ARCHIVE / LINK ==="
test -d "$WEBSITE_ROOT/.git" || { echo "ПОМИЛКА: не знайдено Website: $WEBSITE_ROOT" >&2; exit 20; }
cd "$WEBSITE_ROOT"
[ -z "$(git status --porcelain)" ] || { echo "ПОМИЛКА: Website має незбережені зміни:" >&2; git status --short >&2; exit 21; }
git fetch --all --prune
git checkout main
git pull --ff-only origin main
mkdir -p downloads
find downloads -maxdepth 1 -type f -iname '*TDriver*.zip' -delete
cp -f "$ARCHIVE_PATH" "downloads/$ARCHIVE_NAME"
python - "$WEBSITE_ROOT" "$ARCHIVE_NAME" <<'PY'
from pathlib import Path
import re, sys
root=Path(sys.argv[1]); archive=sys.argv[2]
files=[p for p in root.rglob('*') if p.is_file() and p.suffix.lower() in {'.html','.js','.json','.md'} and '.git' not in p.parts]
changed=[]
for p in files:
    text=p.read_text(encoding='utf-8', errors='ignore'); original=text
    text=re.sub(r'Rodavarion_TDriver_[A-Za-z0-9()._-]+\.zip', archive, text, flags=re.I)
    text=re.sub(r'(/downloads/)[^"\'\s<>]*TDriver[^"\'\s<>]*\.zip', r'\1'+archive, text, flags=re.I)
    if text != original: p.write_text(text, encoding='utf-8'); changed.append(str(p.relative_to(root)))
if not any(archive in p.read_text(encoding='utf-8', errors='ignore') for p in files):
    raise SystemExit('ПОМИЛКА: посилання TDriver на сайті не знайдено/не оновлено')
print('Updated:', ', '.join(changed) if changed else 'existing current reference')
PY

echo "=== 5/6 COMMIT / PUSH / DEPLOY ==="
git add .
git diff --cached --check
if ! git diff --cached --quiet; then git commit -m "Publish TDriver ${VERSION} Stable"; git push origin main; fi
DEPLOY="$(npx --yes wrangler@latest pages deploy . --project-name "$PROJECT_NAME" --branch main --commit-dirty=true 2>&1)"
printf '%s\n' "$DEPLOY"
URL="$(grep -Eo 'https://[a-z0-9]+\.rodavarion\.pages\.dev' <<<"$DEPLOY" | head -n1)"
test -n "$URL"

echo "=== 6/6 AUDIT ==="
for attempt in {1..24}; do
  echo "Audit $attempt/24"
  PAGE="$(curl -fsS "$URL/" || true)"
  CODE="$(curl -L -sS -o /dev/null -w '%{http_code}' "$URL/downloads/$ARCHIVE_NAME" || true)"
  GH_ASSET="$(gh release view "$TAG" --repo Rodavarion/Rodavarion_TDriver --json assets --jq '.assets[].name' 2>/dev/null || true)"
  INSTALLED_VERSION="$($HOME/.local/bin/rodavarion-tdriverctl --version 2>/dev/null | grep -Eo '[0-9]+\.[0-9]+\.[0-9]+' | head -n1 || true)"
  if grep -q "$ARCHIVE_NAME" <<<"$PAGE" && [ "$CODE" = 200 ] && grep -qx "$ARCHIVE_NAME" <<<"$GH_ASSET" && [ "$INSTALLED_VERSION" = "$VERSION" ]; then
    echo "PASS: Rodavarion TDriver $VERSION Stable — READY FOR PUBLIC RELEASE"
    echo "Preview: $URL"
    echo "Public archive: https://rodavarion.org/downloads/$ARCHIVE_NAME"
    exit 0
  fi
  sleep 10
done

echo "ПОМИЛКА: deployment audit failed" >&2
exit 22
)
status=$?
if [ "$status" -ne 0 ]; then echo "TDriver release failed (code $status). Надішли журнал." >&2; fi
exit "$status"
